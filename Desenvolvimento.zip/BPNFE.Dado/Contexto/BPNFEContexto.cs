﻿using System.Data.Entity;
namespace BPNFE.Dado.Contexto
{
    public class BPNFEContexto : DbContext
    {
    }
}
