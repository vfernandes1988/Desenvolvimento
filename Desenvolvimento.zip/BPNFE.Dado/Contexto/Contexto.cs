﻿using System.Data.Entity;
using BPNFE.Dominio.Entidades;

namespace BPNFE.Dado.Contexto
{
    public class Contexto : DbContext
    {
        public Contexto()
            : base("BANCO")
        {
        }

        public DbSet<Cliente> Clientes { get; set; }
    }
}